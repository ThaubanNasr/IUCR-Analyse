# HTML-Template für MISTA

Die HTML-Datei folgt exakt dieser Struktur. Alle CSS-Klassen, JS-Logik und Inhaltsformate exakt übernehmen.

---

## Grundstruktur

```html
<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MISTA – [TT.MM.JJJJ]</title>
  <style>/* CSS einfügen */</style>
</head>
<body>

<div class="header">
  <div class="header-left">
    <h1>MISTA – My Action Required</h1>
    <div class="subtitle">[TT. Monat JJJJ] · WoCCo KBV-Kategorisierung</div>
    <div class="badges">
      <span class="badge badge-total">[N] Cases</span>
      <span class="badge badge-s">S: [N]</span>
      <span class="badge badge-m">M: [N]</span>
      <span class="badge badge-l">L: [N]</span>
      <span class="badge" style="background:rgba(255,255,255,0.1);color:#8892b0">Waiting for WoCCo Feedback</span>
    </div>
  </div>
  <div class="search-box">
    <input type="text" id="searchInput" placeholder="Suchen nach Titel, Case-ID, JIRA-ID…" oninput="filterCases()">
  </div>
</div>

<div class="section">
  <div class="section-title">My Action Required</div>
  <!-- Case-Cards hier -->
</div>

<script>/* JS einfügen */</script>
</body>
</html>
```

---

## CSS

```css
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
body { background: #f1f4f8; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; font-size: 14px; color: #1a1a2e; }

.header { background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); color: #fff; padding: 24px 32px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 16px; }
.header-left h1 { font-size: 22px; font-weight: 700; letter-spacing: 0.5px; }
.header-left .subtitle { font-size: 12px; color: #8892b0; margin-top: 4px; }
.badges { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 12px; }
.badge { padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; }
.badge-total { background: rgba(255,255,255,0.15); }
.badge-s { background: #1a7a4a22; color: #4ade80; border: 1px solid #4ade8055; }
.badge-m { background: #92400022; color: #fbbf24; border: 1px solid #fbbf2455; }
.badge-l { background: #7f1d1d22; color: #f87171; border: 1px solid #f8717155; }
.search-box input { background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); border-radius: 8px; color: #fff; padding: 8px 14px; font-size: 13px; width: 260px; outline: none; }
.search-box input::placeholder { color: #8892b0; }
.search-box input:focus { border-color: rgba(255,255,255,0.5); }

.section { padding: 28px 32px; }
.section-title { font-size: 16px; font-weight: 700; color: #16213e; margin-bottom: 16px; padding-bottom: 8px; border-bottom: 2px solid #e2e8f0; }

.case-card { background: #fff; border-radius: 12px; box-shadow: 0 1px 4px rgba(0,0,0,0.07); margin-bottom: 12px; overflow: hidden; }
.case-header { display: flex; align-items: center; gap: 12px; padding: 16px 20px; cursor: pointer; user-select: none; transition: background 0.15s; }
.case-header:hover { background: #f8fafc; }
.cat-badge { width: 32px; height: 32px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 15px; flex-shrink: 0; }
.cat-s { background: #dcfce7; color: #16a34a; }
.cat-m { background: #fef9c3; color: #ca8a04; }
.cat-l { background: #fee2e2; color: #dc2626; }
.case-meta { flex: 1; min-width: 0; }
.case-title { font-weight: 600; font-size: 14px; color: #1a1a2e; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.case-id { font-size: 12px; color: #64748b; margin-top: 2px; }
.case-tags { display: flex; gap: 6px; flex-wrap: wrap; margin-top: 6px; }
.tag { font-size: 11px; padding: 2px 8px; border-radius: 10px; background: #f1f5f9; color: #475569; }
.tag-ai { background: #ede9fe; color: #7c3aed; }
.tag-joule { background: #dbeafe; color: #1d4ed8; }
.tag-sbpa { background: #fce7f3; color: #be185d; }
.jira-link { font-size: 12px; color: #3b82f6; text-decoration: none; font-weight: 500; white-space: nowrap; }
.jira-link:hover { text-decoration: underline; }
.chevron { color: #94a3b8; font-size: 12px; transition: transform 0.2s; flex-shrink: 0; margin-left: 8px; }
.chevron.open { transform: rotate(90deg); }

.case-body { display: none; padding: 0 20px 20px; border-top: 1px solid #f1f4f8; }
.case-body.open { display: block; }
.grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-top: 16px; }
.card-pbz { border-left: 4px solid #3b82f6; background: #f8faff; border-radius: 8px; padding: 14px; }
.card-auswirkung { border-left: 4px solid #8b5cf6; background: #faf8ff; border-radius: 8px; padding: 14px; }
.card-title { font-weight: 600; font-size: 13px; margin-bottom: 8px; color: #374151; }
.card-body { font-size: 13px; color: #4b5563; line-height: 1.6; }
.card-body ul { padding-left: 16px; }
.card-body li { margin-bottom: 3px; }

.mitigation-block { margin-top: 14px; }
.mitigation-title { font-weight: 600; font-size: 13px; color: #374151; margin-bottom: 10px; }
.mitigation-grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.mitigation-grid-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; }
.mit-card { background: #f8fafc; border-radius: 8px; padding: 12px; border: 1px solid #e2e8f0; }
.mit-card h4 { font-size: 12px; font-weight: 700; color: #374151; margin-bottom: 6px; text-transform: uppercase; letter-spacing: 0.5px; }
.mit-card ul { font-size: 12px; color: #4b5563; padding-left: 14px; }
.mit-card li { margin-bottom: 3px; }

/* GUTACHTEN */
.gutachten-btn { margin-top: 14px; background: none; border: 1px solid #cbd5e1; border-radius: 8px; padding: 7px 14px; font-size: 12px; font-weight: 600; color: #475569; cursor: pointer; transition: all 0.15s; }
.gutachten-btn:hover { background: #f1f5f9; border-color: #94a3b8; }
.gutachten-content { display: none; margin-top: 10px; background: #f8fafc; border-radius: 8px; padding: 16px; font-size: 13px; color: #374151; white-space: pre-wrap; line-height: 1.7; border: 1px solid #e2e8f0; }
.gutachten-content.open { display: block; }

/* FAZIT — separates Element nach .gutachten-content, standardmäßig versteckt */
.gutachten-fazit { display: none; border-radius: 6px; padding: 10px 14px; margin-top: 6px; font-weight: 600; font-size: 13px; }
.gutachten-fazit.open { display: block; }
.fazit-s { background: #dcfce7; color: #15803d; }
.fazit-m { background: #fef9c3; color: #92400e; }
.fazit-l { background: #fee2e2; color: #991b1b; }

@media (max-width: 700px) {
  .header { padding: 16px; } .section { padding: 16px; }
  .grid-2, .mitigation-grid-2, .mitigation-grid-3 { grid-template-columns: 1fr; }
  .search-box input { width: 100%; }
}
```

---

## Case-Card HTML-Struktur

```html
<div class="case-card" data-search="[case-id] [jira-id] [titel lowercase]">
  <div class="case-header" onclick="toggleCase(this)">
    <div class="cat-badge cat-[s|m|l]">[S|M|L]</div>
    <div class="case-meta">
      <div class="case-title">[TITEL]</div>
      <div class="case-id">[CASE-ID] · [TT.MM.JJJJ]</div>
      <div class="case-tags">
        <span class="tag tag-[ai|joule|sbpa]">[Solution Type]</span>
        <span class="tag">SP [N] – [DIY|Full Service|...]</span>
        <span class="tag">[Board Area]</span>
        <!-- AI Ethics Tag nur wenn gesetzt: -->
        <span class="tag" style="background:#dcfce7;color:#16a34a">AI Ethics: Standard</span>
      </div>
    </div>
    <a class="jira-link" href="https://jira.tools.sap/browse/[JIRA-ID]" target="_blank" onclick="event.stopPropagation()">[JIRA-ID] ↗</a>
    <span class="chevron">▶</span>
  </div>
  <div class="case-body">
    <div class="grid-2">
      <div class="card-pbz">
        <div class="card-title">Personenbezogene Daten</div>
        <div class="card-body"><ul><li>...</li></ul></div>
      </div>
      <div class="card-auswirkung">
        <div class="card-title">Auswirkungen auf Mitarbeitende</div>
        <div class="card-body"><ul><li>...</li></ul></div>
      </div>
    </div>
    <div class="mitigation-block">
      <div class="mitigation-title">Mitigationsmaßnahmen</div>
      <div class="mitigation-grid-[2|3]">
        <div class="mit-card"><h4>Bereits geplant</h4><ul><li>...</li></ul></div>
        <div class="mit-card"><h4>Empfohlen</h4><ul><li>...</li></ul></div>
        <!-- Nur bei M/L: -->
        <div class="mit-card"><h4>Upgrade auf S möglich?</h4><ul><li>...</li></ul></div>
      </div>
    </div>

    <!-- GUTACHTEN: Button + Fließtext + Fazit als drei separate Elemente -->
    <button class="gutachten-btn" onclick="toggleGutachten(this); event.stopPropagation()">Gutachten ▾</button>
    <div class="gutachten-content">[NUR FLIESSTEXT — KEIN FAZIT-DIV HIER]</div>
    <div class="gutachten-fazit fazit-[s|m|l]">[FAZIT-TEXT]</div>
  </div>
</div>
```

> **Wichtig:** Das `.gutachten-fazit`-Element steht **nach** dem `.gutachten-content`, niemals darin.
> Der Fazit-Text enthält nur den lesbaren Text, keine HTML-Tags.
> Beide Elemente werden von `toggleGutachten()` gemeinsam ein-/ausgeblendet.

---

## JavaScript

```javascript
function toggleCase(header) {
  const body = header.nextElementSibling;
  const chevron = header.querySelector('.chevron');
  const isOpen = body.classList.contains('open');
  body.classList.toggle('open', !isOpen);
  chevron.classList.toggle('open', !isOpen);
}

function toggleGutachten(btn) {
  const content = btn.nextElementSibling;        // .gutachten-content
  const fazit   = content.nextElementSibling;   // .gutachten-fazit
  const isOpen  = content.classList.contains('open');
  content.classList.toggle('open', !isOpen);
  if (fazit) fazit.classList.toggle('open', !isOpen);
  btn.textContent = isOpen ? 'Gutachten ▾' : 'Gutachten ▴';
}

function filterCases() {
  const term = document.getElementById('searchInput').value.toLowerCase();
  document.querySelectorAll('.case-card').forEach(card => {
    const text = (card.dataset.search + ' ' + card.textContent).toLowerCase();
    card.style.display = text.includes(term) ? '' : 'none';
  });
}
```

---

## Service-Package-Abkürzungen

| Volltext | Tag-Anzeige |
|---|---|
| 1 - Do It Yourself (Citizen Development) | SP 1 – DIY |
| 4 - PoC, Development & Ops (Full Service Package) | SP 4 – Full Service |

## Solution-Type CSS-Klassen

| Solution Type | CSS-Klasse |
|---|---|
| Artificial Intelligence | tag-ai |
| Joule Studio Agent | tag-joule |
| SAP Build Process Automation | tag-sbpa |

## AI Ethics Tag Farben

| Klassifizierung | Style |
|---|---|
| Standard | background:#dcfce7;color:#16a34a |
| High Risk | background:#fee2e2;color:#dc2626 |
| Not yet Classified / null | nicht anzeigen |
