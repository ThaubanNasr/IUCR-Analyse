---
name: mista-kbv-kategorisierung
description: >-
  Erstellt eine MISTA-Analyse (KBV-Kategorisierung S/M/L) für IUCR AI-Cases. Aktiviert bei: "erstell eine MISTA", "my action required", "KBV-Analyse", "kategorisiere Cases", "neue Cases analysieren", "MISTA erstellen".
allowed-tools: write_file read_file execute
---

# MISTA — KBV-Kategorisierungsanalyse

## Ziel
Erstelle eine vollständige KBV-Kategorisierungsanalyse als HTML-Datei mit dem Dateinamen `mista_TT-MM-JJJJ.html`
(heutiges Datum im Dateinamen, z. B. `mista_06-08-2026.html`).

Den Speicherpfad gemäß **Schritt 4** bestimmen (Primärpfad mit Fallback).

---

## Schritt 1 — Modus bestimmen

**Standard (keine weiteren Angaben):**
- Nur „My Action Required“: Filter `APR__WOCCO__STATUS = 'Waiting for WoCCo Feedback'`
- Sortierung: `LIFECYCLE__CREATED_DATE desc`
- Kein zweiter Abschnitt

**Mit Anzahl (z. B. „5 neueste“ oder „10 neueste“):**
- Abschnitt 1 — My Action Required: WoCCo-Filter, IDs merken
- Abschnitt 2 — Neue Cases: kein WoCCo-Filter, absteigende Sortierung, genannte Anzahl, My-Action-Required-IDs per `not in` ausschließen

**Mit expliziten IDs (IRPA-R... oder INTAI-...):**
- Nur diese Cases abrufen, kein WoCCo-Filter, keine Zweiteilung

---

## Schritt 2 — Daten abrufen

### IUCR Cases (MCP)
- Connector: IUCR MCP
- Kein STATUS-, SOLUTION_TYPE- oder SERVICE_PACKAGE-Filter für My Action Required
- Pflichtfelder: ID, Titel, Beschreibung, Solution Type, Service Package, Status, Created Date,
  APR__WOCCO__STATUS, AI Ethics Klassifizierung, geplante Mitigationsmaßnahmen

### JIRA-Tickets (falls INTAI-ID vorhanden)
- Connector: JIRA MCP
- Felder: Summary, Status, Description, Labels, Priority
- Informationen zur Kategorisierung nutzen

---

## Schritt 3 — Jeden Case analysieren

Für jeden Case vollständig analysieren gemäß `references/kbv_logic.md`:

1. Verarbeitung personenbezogener Daten prüfen
2. Auswirkungen auf Arbeitsprozesse / Mitarbeitende prüfen
3. KBV-Kategorie S / M / L bestimmen
4. Gutachten erstellen (Fließtext + separater Fazit-Block, siehe unten)

### Gutachten-Struktur

Das Gutachten besteht aus **zwei separaten HTML-Elementen**:

1. **`.gutachten-content`** (white-space: pre-wrap) — enthält ausschließlich den Fließtext:

```
Kategorisierung: Kategorie [S/M/L]
Der KI-Anwendungsfall "[Name]" fällt in Kategorie [X] basierend auf folgender Analyse:

Begründung der Kategorisierung

1. Verarbeitung personenbezogener Daten
[Kernbefund]:
- Punkt 1
- Punkt 2

2. Auswirkungen auf Arbeitsprozesse
[Eingriffstiefe]:
- Punkt 1
- Punkt 2

Erforderliche Mitigationsmaßnahmen

Folgende Mitigationsmaßnahmen sollten implementiert werden:

1. Bereits geplante/implementierte Maßnahmen:
[Maßnahme]: [Beschreibung]

2. Empfohlene zusätzliche Mitigationsmaßnahmen:
[Maßnahme]: [Beschreibung]

3. Mögliche Mitigation zur Kategorie S:   ← nur bei M oder L
Der Anwendungsfall könnte in Kategorie S eingeordnet werden, wenn:
- [Bedingung]
```

2. **`.gutachten-fazit.fazit-[s|m|l]`** — direkt nach `.gutachten-content`, als eigenständiges HTML-Element:

```html
<div class="gutachten-fazit fazit-[s|m|l]">[Fazit-Text]</div>
```

> **WICHTIG:** Das Fazit-`<div>` gehört **niemals** in den Fließtext des `.gutachten-content`. Es wird immer als separates HTML-Element nach dem Textblock eingefügt. Nur so wird es korrekt als farbiger Block gerendert statt als HTML-escaped Text angezeigt.

Beide Elemente werden durch `toggleGutachten()` gemeinsam ein- und ausgeblendet.

---

## Sprachregeln — für Betriebsrat und Management

Alle Analyse-Texte (Gutachten, Bullet Points, Mitigationsmaßnahmen) müssen für Betriebsrat und Management verständlich sein — **nicht** für Entwickler.

### Verbindliche Ersetzungen

| Niemals verwenden | Stattdessen |
|---|---|
| `German Employees: false` | „Keine deutschen Mitarbeitenden betroffen“ |
| `German Employees: true` | „Deutsche Mitarbeitende betroffen“ |
| `(Feld: true)` / `(Feld: false)` | Weglassen oder in Fließtext übersetzen |
| `Human-in-the-Loop` | „Menschliche Überprüfung / Freigabe“ |
| `Auto-Dispatch` | „Automatische Zuweisung“ |
| `LLM-Eingriff` / `LLM` | „KI-Eingriff“ / „KI“ |
| `headless` | „servergesteuert“ oder weglassen |
| `automation-first` | „automatisierungsorientiert“ |
| `RAG` | „KI-gestützter Wissensabruf“ |
| `CI/CD` | „Entwicklungspipelines“ |
| Technische Feldnamen (`APR__WOCCO__STATUS` etc.) | Nie in Analysetexte übernehmen |
| `true` / `false` als Werte | In Klartextsprache übersetzen |
| `Control/Behaviour: false` | Weglassen |

### Grundsätze

- **Fachlich, nicht technisch:** Jede Aussage muss von jemandem ohne IT-Hintergrund verstanden werden.
- **Englisch nur wenn allgemein bekannt:** „KI“, „Pilot“, „Portfolio“, „KPI“ sind akzeptiert.
- **Keine Systemfeldnamen:** Nur inhaltliche Beschreibungen, niemals Datenbank- oder API-Feldnamen.
- **Direkte Sprache:** Aktive Formulierungen bevorzugen.
- **Mitarbeitendenbetroffenheit klar benennen:** Immer explizit angeben, ob und welche Mitarbeitendengruppen betroffen sind.

---

## Schritt 4 — HTML-Datei erstellen

HTML-Struktur gemäß `references/html_template.md` verwenden.

### Dateiname

Format: `mista_TT-MM-JJJJ.html` — Beispiel: `mista_06-08-2026.html`

- Das heutige Datum bestimmen und in das Format `TT-MM-JJJJ` bringen.
- Existiert im Zielordner bereits eine Datei mit diesem Namen (gleicher Tag = gleiche Version), wird sie überschrieben.
- **Dateien anderer Tage werden niemals angetastet.** Kein Aufräumen, kein `os.remove` für fremde Dateien.

### Speicherpfad — Primär mit Fallback

Den Zielordner per `execute` ermitteln:

```python
import os
from datetime import date

primary = r"C:\Users\I777951\OneDrive - SAP SE\IT Works Council Collaboration (IT WoCCo)-Internal - IT WoCCo - Documents\2026_AI_Cases\AI Review Mista"
fallback = "Documents/MISTA"

if os.path.isdir(primary):
    target_dir = primary
else:
    os.makedirs(fallback, exist_ok=True)
    target_dir = fallback

today = date.today()
filename = f"mista_{today.day:02d}-{today.month:02d}-{today.year}.html"
out_path = os.path.join(target_dir, filename)
print(f"TARGET:{out_path}")
```

Den ausgegebenen Pfad (`TARGET:...`) als Zielpfad für `write_file` verwenden.

### Datei schreiben

Datei per `write_file` unter dem ermittelten Pfad speichern → erscheint als Artifact-Chip im Chat.

### Nutzer informieren

Nach dem Speichern dem Nutzer mitteilen:
- **Wo** die Datei gespeichert wurde (Primärpfad oder Fallback)
- Ob eine bestehende Datei des heutigen Tages überschrieben oder eine neue Datei angelegt wurde
- Anzahl Cases, Kategorienverteilung (S / M / L)